

<?php $__env->startSection('content'); ?>


    <!-- contact section -->

    <section class="contact_section layout_padding">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-5 col-lg-4 offset-md-1 offset-lg-2">
            <div class="form_container">
              <div class="heading_container">
                <h2>
                  Bizga Bog'lanish
                </h2>
              </div>
              <form action="">
                <div>
                  <input type="text" placeholder="Ism To'liq " />
                </div>
                <div>
                  <input type="text" placeholder="Telefon raqam" />
                </div>
                <div>
                  <input type="email" placeholder="Email" />
                </div>
                <div>
                  <input type="text" class="message-box" placeholder="SMS" />
                </div>
                <div class="d-flex ">
                  <button>
                    Hozr Jonating
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div class="col-md-6  px-0">
            <div class="map_container">
              <div class="map">
                <div id="googleMap"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- end contact section -->


    <!-- info section -->
   

    <!-- end info_section -->

  </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mine\resources\views/layout/contact.blade.php ENDPATH**/ ?>