

<?php $__env->startSection('content'); ?>

    <!-- about section -->
 
    <section class="offer_section layout_padding">
      <div class="container">
        <div class="box">
          <div class="detail-box">
            <h2>
              Tavsiyalar
            </h2>
            <h3>
              5% skidka <br>
              turli xil shokoladlar
            </h3>
            <a href="">
              Hozr oling
            </a>
          </div>
          <div class="img-box">
            <img src="assets/images/offer-img.png" alt="">
          </div>
        </div>
        <div class="btn-box">
          <a href="">
            <span>
              Ko'proq ko'rish
            </span>
            <img src="assets/images/color-arrow.png" alt="">
          </a>
        </div>
      </div>
    </section>
    </div>
    <?php $__currentLoopData = $massiv1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <section class="about_section layout_padding ">
      <div class="container  ">
        <div class="row">
          <div class="col-md-6">
            <div class="detail-box">
              <div class="heading_container">
                <h2>
                  <?php echo e($mas->title); ?>

                </h2>
              </div>
              <p>
              <?php echo e($mas->text); ?> </p>
              <a href="#">
                <span>
                 Ko'proq
                </span>
                <img src="assets/images/<?php echo e($mas->img); ?>" alt="">
              </a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="img-box">
              <img src="assets/images/<?php echo e($mas->img); ?>" alt="">
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <!-- end about section -->


    <!-- info section -->
    

    <!-- end info_section -->

  

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mine\resources\views/layout/about.blade.php ENDPATH**/ ?>