

<?php $__env->startSection('content'); ?>

    <!-- chocolate section -->
    
    <section class="chocolate_section layout_padding">
      <div class="container">
        <div class="heading_container">
          <h2>
            Bizning shokolad turlarimiza
          </h2>
          <p>
          Shokolad yurak-qon tomir faoliyatiga ijobiy ta'sir ko‘rsatadi, uning tarkibidagi glyukoza esa aqliy va jismoniy faoliyatni yaxshilaydi. 
          </p>
        </div>
      </div>
      
      <div class="container">
        <div class="chocolate_container">
        <?php $__currentLoopData = $massiv2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mas2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="box">
            <div class="img-box">
              <img src="assets/images/<?php echo e($mas2->img); ?>" alt="">
            </div>
            <div class="detail-box">
              <h6>
              <?php echo e($mas2->name); ?> <span>chocolato</span>
              </h6>
              <h5>
              $<?php echo e($mas2->cost); ?>

              </h5>
              <a href="">
                HOZR SOTIB OLING
              </a>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
     
      </div>
    </section>
   
    <!-- end chocolate section -->

    <!-- info section -->
    

    <!-- end info_section -->

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mine\resources\views/layout/chocolate.blade.php ENDPATH**/ ?>